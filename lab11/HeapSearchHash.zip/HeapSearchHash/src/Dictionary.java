import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public class Dictionary {
    public static void main(String[] args) throws FileNotFoundException {
        HashMap<String, String> dict = new HashMap<String, String>();
        File f = new File("./example_words.txt");
        try (Scanner scanLine = new Scanner(f)) {
            while(scanLine.hasNext()) {
                String line = scanLine.nextLine();
                String[] word = line.split("\t", 2);
                dict.put(word[0], word[1]);
            }
        }
        try (Scanner inScanner = new Scanner(System.in)) {
            String key = inScanner.nextLine();
            System.out.println(dict.get(key));
        }
    }
}