public class Employee implements Cloneable {

	// Initializes instance variables.
	private String name;
	private int no;
	private int age;
	private String state;
	private int zip;
	private String aName;


	public Employee() {

		name = null;
		no = 0;
		age = 0;
		state = null;
		zip = 0;
		aName = null;

	} // end constructor

    public Employee(String name, int no, int age, String state, int zip, String aName) {
        this.name = name;
        this.no = no;
        this.age =age;
        this.state = state;
        this.zip = zip;
        this.aName = aName;
    }


	public Employee(Object obj) {

		// Checks for precondition
		if ((obj != null) && (obj instanceof Employee)) {

			// Copies all variable of obj
			// to the new object called emp.
			Employee emp = (Employee) obj;
			this.name = new String(emp.name);
			this.no = emp.no;
			this.age = emp.age;
			this.state = new String(emp.state);
			this.zip = emp.zip;
			this.aName = new String(emp.aName);

		} // end if

	} // end copy constructor


	public Employee clone() {

		Employee answer;
		try {

			// Creates clone and then copies all variables to clone.
			answer = (Employee) super.clone();
			answer.name = new String(name);
			answer.no = no;
			answer.age = age;
			answer.state = new String(state);
			answer.zip = zip;
			answer.aName = new String(aName);

		} // end try

		// Catches an exception if necessary.
		catch (CloneNotSupportedException e) {

			// Throws RuntimeException and prints a message.
			System.out.println(e.getMessage());
			throw new RuntimeException("This class does not implement Cloneable.");

		} // end catch

		// Returns new clone.
		return answer;

	} // end clone


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

	public int getNo() {
		return no;
	}


	public void setNo(int no) {
		this.no = no;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public int getZip() {
		return zip;
	}


	public void setZip(int zip) {
		this.zip = zip;
	}


	public String getAdvisor() {
		return aName;
	}


	public void setAdvisor(String advisor) {
		// Properly copies the array parameter
		this.aName = advisor;
	}

	public String toString() {

		// Returns the employee info with the string
		// from the advisors array.
		return "Name: " + name + "\nEmployee #: " + no + "\nAge: " + age + "\nState: " + state + "\nZipcode: " + zip
				+ "\nAdvisor Name: " + aName + "\n";

	} // end toString


	public boolean equals(Object obj) {

		// Checks obj for precondition.
		if ((obj != null) && (obj instanceof Employee)) {

			// Returns true if variables match.
			Employee temp = (Employee) obj;
			return temp.no == no;

		} // end if

		// Returns false if they don't match.
		return false;

	} // end equals


	public static String[] getAllAdvisors(Employee e1, Employee e2) {

		// Checks if e1 and e2 are null.
		if ((e1 == null) && (e2 == null))
			throw new IllegalArgumentException("At least one parameter must not be null.");

		if (e1.aName.compareTo(e2.aName) == 0) {
			String advisors[] = {e1.aName};
			return advisors;
		} // end if
		
		String advisors[] = {e1.aName, e2.aName};
		return advisors;

	} // end getAllAdvisors

} // end classclass Employee {
