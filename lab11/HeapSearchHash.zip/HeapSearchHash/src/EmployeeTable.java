public class EmployeeTable {
    private int num;
    private Employee[] data;
    private boolean[] used;

    public EmployeeTable(int capacity){
        this.num = 0;
        this.data = new Employee[capacity];
        this.used = new boolean[capacity];
    }

    public void put(Employee e){
        int idx = this.search(e.getNo());
        if (idx != -1) {
            throw new IllegalStateException("Employee already exists in the table.");
        }
        else if (this.num < this.data.length) {
            idx = this.hash(e.getNo());
            while(this.used[idx] == true) {
                idx = this.nextIndex(idx);
            }
            this.data[idx] = e;
            this.used[idx] = true;
            this.num++;
        }
        else {
            throw new IllegalStateException("Table is full.");
        }
    }

    public boolean remove(Employee e) {
        int idx = this.search(e.getNo());
        if (idx != -1) {
            this.data[idx] = null;
            this.used[idx] = false;
            this.num--;
            return true;
        }
        return false;
    }

    private int nextIndex(int i) {
        if (i+1 == this.data.length) {
            return 0;
        }
        else {
            return i+1;
        }
    }

    private int search(int emp_no) {
        int idx = this.hash(emp_no);
        int counter = 0;
        while (counter < this.data.length && this.used[idx] == true) {
            if (this.data[idx].getNo() == emp_no) return idx;
            counter++;
            idx = this.nextIndex(idx);
        }
        return -1;
    }

    private int hash(int emp_no) {
        return Math.abs(emp_no) % this.data.length;
    }

    public static void main(String[] args) {
        Employee e1 = new Employee("Alex", 13, 20, "Texas", 29372, "Lexi");
        Employee e2 = new Employee("Bella", 14, 20, "Michigan", 29372, "B");
        Employee e3 = new Employee("John", 16, 20, "New Mexico", 29372, "Johnny");
        Employee e4 = new Employee("Will", 31, 20, "Florida", 29372, "Bill");
        Employee e5 = new Employee("Jack", 37, 20, "Florida", 29372, "Bill");
        Employee e6 = new Employee("Phil", 38, 20, "Florida", 29372, "Bill");
        EmployeeTable empTable = new EmployeeTable(5);
        empTable.put(e1);
        empTable.put(e2);
        empTable.put(e3);
        empTable.put(e4);
        empTable.put(e5);
        // empTable.put(e6);
        for (Employee e : empTable.data) {
            if (e != null)
                System.out.printf("%s ", e.getName());
        }
        System.out.println("\n");
        empTable.remove(e1);
        for (Employee e : empTable.data) {
            if (e != null)
                System.out.printf("%s ", e.getName());
        }
        System.out.println("\n");
    }
}
