import java.util.ArrayList;

public class MinHeap {
    private ArrayList<Integer> heap;

    public MinHeap() {
        setHeap(new ArrayList<Integer>(10));
    }

    public ArrayList<Integer> getHeap() {
        return heap;
    }

    public void setHeap(ArrayList<Integer> heap) {
        this.heap = heap;
    }

    private void swap(int i, int j) {
        int tmp = heap.get(i);
        heap.set(i, heap.get(j));
        heap.set(j, tmp);
    }

    public void add(int e) {
        // append the new element at the end of the array
        heap.add(e);
        int curPos = heap.size() - 1;
        // calculate the position of its parent node
        int parentPos = (curPos + 1) / 2 - 1;
        // upward the current node if it is smaller than its parent node
        while (curPos != 0 && heap.get(curPos) < heap.get(parentPos)) {
            swap(curPos, parentPos);
            curPos = parentPos;
            parentPos = (curPos + 1) / 2 - 1;
        }
    }

    private void downward(int i, int heapSize) {
        int curPos = i;
        int left = curPos*2 + 1;
        int right = curPos*2 + 2;
        // If left child exists and smaller than its parent node
        if (left < heapSize && heap.get(left) < heap.get(curPos)) {
            curPos = left;
        }
        // If right child exists and smaller than its parent node
        if (right < heapSize && heap.get(right) < heap.get(curPos)) {
            curPos = right;
        }
        // If curPos move to its children
        if (curPos != i) {
            swap(curPos, i);
            // Recursive call for subtree
            downward(curPos, heapSize);
        }
    }

    public int remove() {
        if (heap.isEmpty()) {
            return -1;  // return null value
        }
        // Move the last element to the root
        swap(0, heap.size()-1);
        // remove the last element to return
        int ans = heap.remove(heap.size()-1);
        // Downward the min heap
        downward(0, heap.size());
        return ans;
    }

    public int top() {
        if (heap.isEmpty()) {
            return -1;  // return null value
        }
        return heap.get(0);
    }

    public static void main(String[] args) {
        MinHeap minHeap = new MinHeap();
        Integer[] arr = new Integer[] { 19, 27, 35, 21, 45, 22, 23, 4 };
        for (Integer item : arr) {
            System.out.printf("%d ", item);
            minHeap.add(item);
        }
        System.out.print("\n");
        System.out.println(minHeap.getHeap());
        System.out.println(minHeap.top());
        int a = minHeap.remove();
        System.out.println(minHeap.getHeap());
        System.out.println(a);
    }
}
