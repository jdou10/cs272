import java.util.ArrayList;
import java.util.Collections;
import java.lang.Math;

public class Search {
    private static int binSearch(int[] arr, int l, int r, int key) {
        if (l <= r) {
            // Note: we use this formula instead of (l+r)/2 to avoid
            //       stackoverflow when the array is too large.
            int m = l + (r - l) / 2;
            if (arr[m] == key) {
                return m;
            } else if (arr[m] < key) {
                return binSearch(arr, m + 1, r, key);
            } else {
                return binSearch(arr, l, m - 1, key);
            }
        }
        return -1;
    }

    public static int binarySearch(int[] arr, int key) {
        return binSearch(arr, 0, arr.length - 1, key);
    }

    private static Integer findNearest(ArrayList<Integer> A, int l, int r, int target) {
        if (l < r) {
            int m = l + (r - l) / 2;
            if (A.get(m) == target) {
                return A.get(m);
            } else if (A.get(m) < target) {
                return findNearest(A, m + 1, r, target);
            } else {
                return findNearest(A, l, m - 1, target);
            }
        }
        if (Math.abs(target - A.get(l)) <= Math.abs(target - A.get(l-1)))
            return A.remove(l);
        else
            return A.remove(l-1);
    }

    public static ArrayList<Integer> findKNearest(ArrayList<Integer> A, int k, int target) {
        // This function takes O(k*logN) in time complexity
        ArrayList<Integer> ans = new ArrayList<Integer>();
        int size = A.size();
        // Student must handle the case of k larger than array's size
        for (int i = 0; i < Math.min(k, size); i++) {
            // findNearest takes O(logN)
            ans.add(findNearest(A, 0, A.size()-1, target));
        }
        Collections.sort(ans);
        return ans;
    }
    public static void main(String[] args) {
        int[] arr = new int[] { 4, 18, 21, 22, 23, 27, 35, 45 };
        System.out.println(Search.binarySearch(arr, 100));
        System.out.println(Search.binarySearch(arr, 21));
        System.out.println(Search.binarySearch(arr, 45));
        ArrayList<Integer> A = new ArrayList<Integer>();
        for (int item : arr) {
            A.add(item);
        }
        System.out.println(Search.findKNearest(A, 3, 100));
    }
}
