package Queue;

import Stack.LinkStack;

public class Palindrome {
    private LinkedQueue<String> queue;
    private LinkStack<String> stack;
    public Palindrome(String s) {
        queue = new LinkedQueue<String>();
        stack = new LinkStack<String>();
        String[] words = s.replaceAll("[^a-zA-Z ]", "").toLowerCase().split("\\s+");
        for (String w : words) {
            // System.out.println(w);
            queue.enqueue(w);
            stack.push(w);
        }
    }
    public boolean checkPalindrome() {
        while (!queue.isEmpty()) {
            String q = queue.dequeue();
            String s = stack.pop();
            if (!q.equals(s)) {
                // System.out.printf("%s : %s\n", q, s);
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        String instring1 = "This is a test, be careful.";
        String instring2 = "You can cage a swallow, can’t you, but you can’t swallow a cage, can you?";
        Palindrome p1 = new Palindrome(instring1);
        System.out.println(p1.checkPalindrome());
        Palindrome p2 = new Palindrome(instring2);
        System.out.println(p2.checkPalindrome());
    }
}
