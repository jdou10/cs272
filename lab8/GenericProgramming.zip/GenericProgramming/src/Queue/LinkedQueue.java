package Queue;

import java.util.EmptyStackException;

import Node.SNode;

public class LinkedQueue<T> implements QueueInterface<T> {
    private SNode<T> front;
    private SNode<T> rear;
    private int manyItems;

    public LinkedQueue() {
        front = null;
        rear = null;
        manyItems = 0;
    }
    
    @Override
    public void enqueue(T val) {
        // TODO Auto-generated method stub
        SNode<T> newNode = new SNode<T>(val, null);
        if (rear == null) {
            rear = newNode;
            front = rear;
        }
        else {
            rear.setLink(newNode);
            rear = newNode;
        }
        manyItems++;
    }

    public SNode<T> getRear() {
        return rear;
    }

    public void setRear(SNode<T> rear) {
        this.rear = rear;
    }

    public SNode<T> getFront() {
        return front;
    }

    public void setFront(SNode<T> front) {
        this.front = front;
    }

    @Override
    public T dequeue() {
        if (this.isEmpty()) {
            throw new EmptyStackException();
        }
        T val = front.getData();
        front = front.getLink();
        return val;
    }

    @Override
    public T front() {
        if (front != null)
            return front.getData();
        return null;
    }

    @Override
    public int size() {
        return manyItems;
    }

    @Override
    public boolean isEmpty() {
        return front == null;
    }

}
