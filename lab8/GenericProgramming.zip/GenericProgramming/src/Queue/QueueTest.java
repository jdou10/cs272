package Queue;

public class QueueTest {
    public static void main(String[] args) {
        Integer[] input_sample = new Integer[]{3,5,3,4,5};
        LinkedQueue<Integer> queue1 = new LinkedQueue<Integer>();
        for (Integer item : input_sample) { 
            queue1.enqueue(item);
        }
        System.out.println(queue1.size());
        System.out.println(queue1.dequeue());
        System.out.println(queue1.dequeue());
        System.out.println(queue1.dequeue());
        System.out.println(queue1.dequeue());
        System.out.println(queue1.dequeue());
        System.out.println(queue1.front());
    }
}
