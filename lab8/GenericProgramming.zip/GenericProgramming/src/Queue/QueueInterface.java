package Queue;

public interface QueueInterface<T> {
    public void enqueue(T val);
    public T dequeue();
    public T front();
    public int size();
    public boolean isEmpty();
}
