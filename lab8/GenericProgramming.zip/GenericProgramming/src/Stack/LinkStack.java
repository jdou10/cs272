package Stack;

import java.util.EmptyStackException;

import Node.SNode;

public class LinkStack<T> implements StackInterface<T> {
    private SNode<T> head;
    public LinkStack() {
        this.head = null;
    }
    public LinkStack(T val) {
        this.head = new SNode<T>(val, null);
    }
    public LinkStack(SNode<T> node) {
        this.head = node;
    }
    @Override
    public void push(T val) {
        SNode<T> new_node = new SNode<T>(val, this.head);
        this.head = new_node;
    }

    public SNode<T> getHead() {
        return head;
    }

    public void setHead(SNode<T> head) {
        this.head = head;
    }

    @Override
    public T pop() {
        if (this.isEmpty()) {
            throw new EmptyStackException();
        }
        T data = this.head.getData();
        this.head = this.head.getLink();
        return data;
    }

    @Override
    public T top() {
        if (this.isEmpty()) {
            throw new EmptyStackException();
        }
        return this.head.getData();
    }

    @Override
    public int size() {
        return this.head.getLength();
    }

    @Override
    public boolean isEmpty() {
        if (this.head == null) {return true;}
        else return false;
    }
}
