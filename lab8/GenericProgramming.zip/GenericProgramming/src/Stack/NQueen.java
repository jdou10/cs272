package Stack;

public class NQueen {
    private int N;
    private ArrayListStack<Integer> stack;

    public NQueen(int N) {
        this.N = N;
        this.stack = new ArrayListStack<Integer>(N);
    }

    public void printStack() {
        while (!this.stack.isEmpty()) {
            Integer q = this.stack.pop();
            for (int i = 0; i < this.N; i++) {
                if (i == q-1) {
                    System.out.print("Q");
                }
                else {
                    System.out.print("-");
                }
            }
            System.out.println();
        }
    }

    public int getN() {
        return N;
    }

    public void setN(int n) {
        this.N = n;
    }

    public boolean checkConflict(Integer qPos) {
        if (stack.isEmpty())
            return false;
        for (int i = 0; i < stack.getManyItems(); i++) {
            // check column
            if (qPos == stack.getData().get(i))
                return true;
            // check diagonal
            if (Math.abs(qPos - stack.getData().get(i)) == (stack.size() - i))
                return true;
        }
        return false;
    }

    public void solve() {
        Integer qPos = 1;
        while (stack.size() < N) {
            while (qPos <= N) {
                if (!checkConflict(qPos)) {
                    stack.push(qPos);
                    qPos = 1;
                }
                else {
                    qPos++;
                }
            }
            if (stack.size() == N) {
                printStack();
            }
            while (!stack.isEmpty() && qPos > N) {
                qPos = stack.pop() + 1;
            }
            if (qPos > N) {
                break;
            }
        }
    }

    public static void main(String[] args) {
        NQueen nQueen = new NQueen(10);
        nQueen.solve();
    }
}
