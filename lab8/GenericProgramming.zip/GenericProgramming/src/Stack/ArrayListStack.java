package Stack;

import java.util.ArrayList;
import java.util.EmptyStackException;

public class ArrayListStack<T> implements StackInterface<T> {
    private ArrayList<T> data;
    private int manyItems;

    public ArrayListStack() {
        this.data = new ArrayList<T>(10);
        this.manyItems = 0;
    }

    public ArrayListStack(int cap) {
        this.data = new ArrayList<T>(cap + 1);
        this.manyItems = 0;
    }

    @Override
    public void push(T val) {
        this.manyItems++;
        if (this.manyItems == this.data.size()) {
            this.data.ensureCapacity(this.manyItems*2 + 1);
        }
        this.data.add(val);
    }

    public int getManyItems() {
        return manyItems;
    }

    public ArrayList<T> getData() {
        return data;
    }

    public int getCapacity() {
        return data.size();
    }

    @Override
    public T pop() {
        if (this.isEmpty()) {
            throw new EmptyStackException();
        }
        T val = this.data.get(this.manyItems-1);
        this.data.remove(this.manyItems-1);
        this.manyItems--;
        return val;
    }

    @Override
    public T top() {
        if (this.isEmpty()) {
            throw new EmptyStackException();
        }
        return this.data.get(this.manyItems-1);
    }

    @Override
    public int size() {
        return this.getManyItems();
    }

    @Override
    public boolean isEmpty() {
        return this.getManyItems() == 0;
    }

}
