package Stack;

public class StackTest {
    public static void main(String[] args) {
        // Test LinkStack
        Integer[] sample_input = new Integer[] { 3, 4, 2, 4, 6 };
        LinkStack<Integer> stack1 = new LinkStack<Integer>();
        System.out.println(stack1.isEmpty());
        for (Integer item : sample_input) {
            stack1.push(item);
        }
        System.out.println(stack1.size());
        System.out.println(stack1.pop());
        System.out.println(stack1.top());

        // Test ArrayListStack
        Integer[] sample_input2 = new Integer[] { 2, 3, 52, 4, 5, 6, 6, 43, 4, 6, 212 };
        ArrayListStack<Integer> stack2 = new ArrayListStack<Integer>();
        System.out.println(stack2.isEmpty());
        for (Integer item : sample_input2) {
            stack2.push(item);
        }
        System.out.println(stack2.size());
        System.out.println(stack2.pop());
        System.out.println(stack2.top());
        System.out.println(stack2.getCapacity());
    }
}