package Node;

public class SNode<T> {
    private T data;
    private SNode<T> link;
    public SNode() {
        this.data = null;
        this.link = null;
    }
    public SNode(T data, SNode<T> link) {
        this.data = data;
        this.link = link;
    } 
    public T getData() {
        return data;
    }
    public SNode<T> getLink() {
        return link;
    }
    public void setLink(SNode<T> link) {
        this.link = link;
    }
    public void setData(T data) {
        this.data = data;
    }
    public int getLength() {
        int count = 0;
        SNode<T> p = this;
        while (p != null) {
            p = p.getLink();
            count++;
        }
        return count;
    }
}