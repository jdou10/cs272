public interface StackInterface<T> {

    void push(T element);


    T pop() throws NullPointerException;


    T top() throws NullPointerException;

    int size();


    boolean isEmpty();
}
