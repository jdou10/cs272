
import java.util.Arrays;

public class Reverse {
    public static void reverse(char[] arr, int left, int right) {
        if (left < right) {
            char ch = arr[left];
            arr[left] = arr[right];
            arr[right] = ch;
            reverse(arr, left + 1, right - 1);
        }
    }

    public static void main(String[] args) {
        char[] arr = new char[]{'A', 'B', 'C', 'D', 'E'};
        System.out.println("before reverse array:" + Arrays.toString(arr));
        reverse(arr, 1, 4);
        System.out.println("reversed array:" + Arrays.toString(arr));
    }
}
