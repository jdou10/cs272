public class Convert {
    public static Integer convert(String str) {
        if (str.isEmpty()) {
            return 0;
        } else {
            Integer ans = (int) ((str.charAt(0) - '0') * Math.pow(10, str.length() - 1));
            return ans + convert(str.substring(1));
        }
    }

    public static void main(String[] args) {
        System.out.println("convert(\"1234\"): " + convert("1234"));
        System.out.println("convert(\"1234566\"): " + convert("1234566"));
    }
}
