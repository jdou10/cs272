public class Fibonacci {
    public static int FibBinaryRecursive(int k){
        if(k<=0){
            return 0;
        }else if(k==1){
            return 1;
        }
        return FibBinaryRecursive(k-1)+FibBinaryRecursive(k-2);
    }

    public static void main(String[] args) {
        System.out.println("Fib(12) = " + FibBinaryRecursive(12));
        System.out.println("Fib(13) = " + FibBinaryRecursive(13));
    }
}
