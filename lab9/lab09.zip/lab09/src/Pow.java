public class Pow {
    public static double pow(double x,int n){
        if(x==0 && n<=0){
            throw new IllegalArgumentException("x is zero and n="+n);
        }
        else if(x==0){
            return 0;
        }else if(n==0){
            return 1;
        }
        else{
            if(n>0){
                double ans=pow(x, n/2);
                if(n%2==0){
                    return ans * ans;
                }else{
                    return x*ans*ans;
                }
            }else{
                return 1.0/pow(x,-n);
            }
        }
    }
    public static void main(String[] args){
        System.out.println("pow(2,5) = "+pow(2,5));
        System.out.println("pow(2,6) = "+pow(2,6));
    }
}
