import java.util.ArrayList;

public class Permutation {
    public static void main(String[] args) {
        ArrayList<Integer> arr = new ArrayList<>();
        arr.add(1);
        arr.add(2);
        arr.add(5);
        arr.add(10);
        for (Integer length : arr) {
            System.out.println("detect the length of " + length);
            int[] nums = new int[length];
            for (int i = 0; i < nums.length; ++i) {
                nums[i] = i + 1;
            }
            permutation(nums, 0, nums.length - 1);
            System.out.println("detect the length of " + length + "   finished");

        }
    }

    public static void permutation(int[] buf,int start,int end) {
        if (start == end) {
            for (int c : buf) {
                System.out.print(c+" ");
            }
            System.out.println();
        } else {
            for (int i = start; i <= end; i++) {
                int temp = buf[start];
                buf[start] = buf[i];
                buf[i] = temp;
                permutation(buf, start + 1, end);
                temp = buf[start];
                buf[start] = buf[i];
                buf[i] = temp;
            }
        }
    }
}
