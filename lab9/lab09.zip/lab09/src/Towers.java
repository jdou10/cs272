
public class Towers {
    private int rings;
    private int[] pegs;
    public Towers(int rings){
        this.rings=rings;
        this.pegs=new int[3];
        for(int i=0;i<pegs.length;++i){
            this.pegs[i]=0;
        }
        this.pegs[0]=rings;
    }


    public int countRings(int pegNumber){
        return this.pegs[pegNumber-1];
    }

    public void setTopDiameter(int pegNumber,int rings){
        this.pegs[pegNumber-1]=rings;
    }

    public int getTopDiameter(int pegNumber){
        return this.pegs[pegNumber-1];
    }

    public void move(int start,int end){
        System.out.println("move [ring "+this.getTopDiameter(start) +"] from "+start+" to "+end);
    }

    public static void Hanoi(int topN, int from, int to,int inter) {
        if (topN == 1) {
            System.out.println("Disk 1 from " + from + " to " + to);
        } else {
            Hanoi(topN - 1, from, inter,to);
            System.out.println("Disk " + topN + " from " + from + " to " + to);
            Hanoi(topN - 1, inter, to,from);
        }
    }
    public static void Hanoi(Towers t,int n,int start,int target,int spare) {
        if(n==1){
            t.setTopDiameter(start,n);
            t.move(start,target);
        }
        else {
            Hanoi(t,n-1,start,spare,target);
            t.setTopDiameter(start,n);
            t.move(start,target);
            Hanoi(t,n-1,spare,target,start);
        }
    }

    public static void main(String[] args){
        Towers t=new Towers(3);
        Hanoi(t,3,1,3,2);
    }
}
