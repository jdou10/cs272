import java.io.*;

public class Welcome {

	public static void main(String[] args) {
		System.out.println("Welcome to Java");
		System.out.println("The current time is: " + System.currentTimeMillis());
		try {
			Welcome.sum();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void sum() throws IOException {
		int sum = 0;
		String line;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Enter a list of integers separated by spaces: ");
		try {
			line = br.readLine();
			String[] numbers = line.split(" ");
			for (int i = 0; i < numbers.length; i++) {
				sum = sum + Integer.parseInt(numbers[i]);
//				System.out.print(numbers[i] + " ");
//				System.out.println();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		br.close();
		System.out.println("Sum of the integers is: " + sum);
	}
}