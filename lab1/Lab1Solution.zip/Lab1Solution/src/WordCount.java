import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.io.PrintWriter;

/**
 * This is the solution for CS272 Lab1 requirement 2. The WordCount class read a
 * text file and then count the occurrences of words in this text file. The
 * result is stored in WordCount.csv
 * 
 * 
 * Output: WordCount.csv $ javac MyTokenizer.java $ java WordCount
 *
 */
class WordCountPair {
	public ArrayList<String> wordList;
	public ArrayList<Integer> countList;
}

public class WordCount {
	public static String[] read(String fname) {
		String text = "";
		String line = "";
		String[] words = null;
		try {
			// FileReader reads text files in the default encoding.
			FileReader fileReader = new FileReader(fname);
			// Always wrap FileReader in BufferedReader.
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			while ((line = bufferedReader.readLine()) != null) {
				text = text + " " + line;
			}
			// Tokenize the text
			StringTokenizer tokenizer = new StringTokenizer(text, " !\"#$%&'()*+,-./:;?@[\\]^_`{|}~");
			int num_tokens = tokenizer.countTokens();
			System.out.println("Total number of tokens found : " + num_tokens);
			words = new String[num_tokens];
			int c = 0;
			while (tokenizer.hasMoreTokens()) {
				String word = tokenizer.nextToken();
				words[c] = word.toLowerCase();
				c++;
			}
			bufferedReader.close(); // Always close files.
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + fname + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + fname + "'");
		}
		return words;
	}

	public static void writeCSV(String fname, WordCountPair data) {
		try (PrintWriter writer = new PrintWriter(new File(fname))) {

			StringBuilder sb = new StringBuilder();

			sb.append("Word");
			sb.append(',');
			sb.append("Count");
			sb.append('\n');

			for (int i = 0; i < data.wordList.size(); i++) {
				sb.append(data.wordList.get(i));
				sb.append(',');
				sb.append(data.countList.get(i));
				sb.append('\n');
			}

			writer.write(sb.toString());

			System.out.println("done writing to CSV file!");

		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	public static WordCountPair countUniq(String[] words) {
		WordCountPair pair = new WordCountPair();
		pair.wordList = new ArrayList<String>();
		pair.countList = new ArrayList<Integer>();

		for (int i = 0; i < words.length; i++) {
			String currWord = words[i];
			if (pair.wordList.contains(currWord)) {
				Integer wordIndx = pair.wordList.indexOf(currWord);
				// Increase the count value of this word
				pair.countList.set(wordIndx, pair.countList.get(wordIndx) + 1);
			} else {
				pair.wordList.add(currWord);
				pair.countList.add(1);

			}
		}

		return pair;

	}

	public static void countUniq_array(String[] words) {
		String[] wordList = new String[words.length];
		int[] countList = new int[words.length];

		for (int i = 0; i < words.length; i++) {
			for (int j = 0; j < wordList.length; j++) {
				if (wordList[j] == null) {
					wordList[j] = words[i];
					countList[j] = 1;
					break;
				}
				if (wordList[j].equals(words[i])) {
					countList[j] = countList[j] + 1;
					break;
				}
			}
		}
		
		for (int i = 0; i < wordList.length; i++) {
			if(wordList[i]==null) {
				break;
			}
			System.out.println(wordList[i]+": " + countList[i]);
		}
	}

	public static void main(String[] args) {
		String[] words = read("pg100_small.txt"); // read a text file
		WordCountPair pair = countUniq(words);
		countUniq_array(words);
		writeCSV("WordCount.csv", pair);
	}
}
